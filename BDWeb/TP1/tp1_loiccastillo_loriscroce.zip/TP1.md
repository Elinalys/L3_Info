# TP1

## Ex 1
```xml
<?xml version="1.0" encoding="utf-8"?>
<Document>
    <Pays nom="France">
        <Capitale>Paris</Capitale>
        <Population date="2007">64102000</Population>
    </Pays>
    <Pays nom="Italie">
        <Capitale>Rome</Capitale>
        <Population date="2006">58133509</Population>
    </Pays>
    <Pays nom="Espagne">
        <Capitale>Madrid</Capitale>
        <Population date="2006">44708964</Population>
    </Pays>
</Document>
```

## Ex 2

1. `xmllint --valid cd-1.xml --noout`

2. Voir changements `cd-2.xml`.

3. `xmllint --schema note.xsd note-1.xml --noout`

4. Voir changements `note-2.xml`.

## Ex 3

Voir `famille.dtd`.

## Ex 4






